import torch
import wandb

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

import plotly.express as px

from collections import Counter

from datasets.SMILESTokenizer import SMILESTokenizer
from datasets.USPTO50 import USPTO50

def analyze(dataset, tokenizer):
    wandb_run = wandb.init(
        project="retrosyn-singlestep",
        entity="yashassamaga",
        tags=["dataset-analysis"])
    wandb_run.log_code()
    with wandb_run:
        
        print([[k, v] for k, v in tokenizer.all_tokens.items()])

        token_distribution = wandb.Table(data=[[k, v] for k, v in tokenizer.all_tokens.items()], columns=["token", "count"]),
        seqlens = wandb.Table(data=[[len(p)] for p, _ in dataset], columns=["length"])
        num_reactants = wandb.Table(data=[[torch.sum(t == tokenizer.get_token_index('.')).item()] for _, t in dataset], columns=["num_reactants"])
        product_repetions = wandb.Table(data=[[v] for v in Counter([tuple(p.tolist()) for p, _ in dataset]).values()], columns=["repeats"])

        df = pd.DataFrame([[k, v] for k, v in tokenizer.all_tokens.items()], columns=["token", "count"])
        # sns.catplot(x="token", kind="count", palette="ch:.25", data=df)
        px.bar(df).show()

        # plt.show()
        exit()
        wandb.log({
            "sequence-lengths" : wandb.plot.histogram(seqlens, "length", title="Sequence Lengths"),
            "token-distribution" : wandb.plot.bar(token_distribution, "token", "count", title="Token Distribution"),
            "num-reactants" : wandb.plot.histogram(num_reactants, "num_reactants", title="Number of reactants"),
            "product-repeats" : wandb.plot.histogram(product_repetions, "repeats", title="Product Repeats")
        })

tokenizer = SMILESTokenizer(["data/USPTO50/src-train.txt",
                            "data/USPTO50/tgt-train.txt",
                            "data/USPTO50/src-val.txt",
                            "data/USPTO50/tgt-val.txt"])

train_dataset = USPTO50("data/USPTO50/src-train.txt", "data/USPTO50/tgt-train.txt", tokenizer)
val_dataset = USPTO50("data/USPTO50/src-val.txt", "data/USPTO50/tgt-val.txt", tokenizer)

analyze(val_dataset, tokenizer)