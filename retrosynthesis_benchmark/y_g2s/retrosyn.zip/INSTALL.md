1. conda install pytorch torchvision torchaudio cudatoolkit=11.3 -c pytorch
2. conda install -c conda-forge wandb rdkit 
3. conda install -c anaconda nltk 
4. pip3 install adabound