import os
import sys
import argparse
import random
import logging
import glob

from importlib import reload
from datetime import datetime

import torch
import wandb
import numpy as np

from datasets.SMILESTokenizer import SMILESTokenizer
from datasets.USPTO50 import Graph2Smiles_USPTO50
from model.graph2smiles.gnn_transformer import GNNTransformer

device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
print(device)

def get_lr_range_finder_config(start_lr, end_lr, num_iter):
    return np.exp(np.log(end_lr/start_lr)/num_iter)

model_config = {
    # Architecture
    "architecture" : {
        "embedding_size" : 128,
        "share_embeddings" : True,
        "tie_decoder_embedding" : True,
        "dropout" : 0.1,
        "nhead" : 8,
        "num_encoder_layers" : 6,
        "num_decoder_layers" : 6,
        "dim_feedforward" : 128
    },

    # Dataset

    # Loss
    "class_reweighting" : False,
    "label_smoothing" : 0.1,

    # Optimizer
    "optimizer" : {
        "type" : "AdamW",
        "params" : {
            "lr" : 1e-4, #6e-5,
            "weight_decay" : 1e-3,
        }
    },
    # "optimizer" : {
    #     "type" : "AdaBound",
    #     "params" : {
    #         "lr" : 2,
    #         "final_lr" : 1e-2,
    #     }
    # },
    # "optimizer" : {
    #     "type" : "SGD",
    #     "params" : {
    #         "lr" : 1,
    #         "weight_decay" : 0,
    #     }
    # },

    "gradient_accumulation_steps" : 1,
    "batch_size" : 32,
    "epochs" : 200,

    # Scheduler
    # "scheduler" : {
    #     "type" : "ReduceLROnPlateau",
    #     "params" : {
    #         "factor" : 0.5,
    #         "patience" : 50,
    #         "cooldown" : 50,
    #         "min_lr" : 1e-6,
    #         "threshold" : 1e-2
    #     }
    # },
    "scheduler" : {
        "type" : "CyclicLR",
        "step_location" : "iteration",
        "params" : {
            "cycle_momentum" : False,
            "base_lr" : 1e-6,
            "max_lr" : 0.001,
            "step_size_up" : 2000,
            "mode" : "triangular"
        }
    },
    # "scheduler" : {
    #     "type" : "OneCycleLR",
    #     "step_location" : "iteration",
    #     "params" : {
    #         "max_lr" : 0.0015,
    #         "steps_per_epoch" : 1001,
    #         "pct_start" : 0.1,
    #         "epochs" : 150
    #     }
    # },
    # "scheduler" : {
    #     "type" : "ExponentialLR",
    #     "step_location" : "iteration",
    #     "params" : {
    #         "gamma" : get_lr_range_finder_config(1e-10, 1, 1000) # for LR finding: np.exp(1/N log(final_lr/initial_lr))
    #     }
    # },

    # Model Selection
    "best_model_threshold" : 0.001,

    "epochs_to_dump_detailed_training_stats" : 20,
    "epochs_to_dump_detailed_validation_stats" : 10,

    # wandb
    "wandb" : {
        # "log_iterationwise" : True,
        "log_epochwise" : True,
        # "watch" : True
    }
}

def train_model(opt, train_dataset, val_dataset, tokenizer):
    logging.shutdown()
    reload(logging)

    logging.basicConfig(
        format="%(asctime)s %(message)s",
        datefmt="[%H:%M:%S]",
        level=logging.INFO,
    )

    logger = logging.getLogger(opt["model_category"])

    wandb_run = wandb.init(
        project="retrosyn-singlestep",
        entity="yashassamaga",
        config=opt,
        tags=[])
    wandb_run.log_code()
    with wandb_run:
        model = GNNTransformer(opt, logger, tokenizer.vocab_size)
        model.init_train()
        model.set_data_loader(train_dataset, val_dataset, tokenizer)
        model.set_criterion()
        model.set_optimizer_and_scheduler()
        model = model.to(device=device)
        if opt["config"]["wandb"].get("watch", False):
            wandb_run.watch(model, log='all')
        model.learn(True)
        
def main():
    parser = argparse.ArgumentParser(description='Train Simles2Smiles')
    args = parser.parse_args()

    model_training_dir = os.path.join(datetime.now().strftime("%Y-%m-%d %H_%M_%S") + "-%d" % random.randint(0, 10000))
    while os.path.exists(model_training_dir):
        model_training_dir = os.path.join(datetime.now().strftime("%Y-%m-%d %H_%M_%S") + "-%d" % random.randint(0, 10000))

    opt = {
        "device" : device,
        "model_category" : "Smiles2Smiles_Transformer",
        "model_subdir" : model_training_dir,
        "config" : model_config,
    }

    tokenizer = SMILESTokenizer(["data/USPTO50/src-train.txt",
                                 "data/USPTO50/tgt-train.txt",
                                 "data/USPTO50/src-val.txt",
                                 "data/USPTO50/tgt-val.txt"])
    
    # dataset = USPTO50("data/USPTO50/src-train.txt", "data/USPTO50/tgt-train.txt", tokenizer)
    # train_len = int(len(dataset) * opt["train_fraction"])
    # val_len = len(dataset) - train_len
    # train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_len, val_len])

    train_dataset = Graph2Smiles_USPTO50("data/USPTO50/src-train.txt", "data/USPTO50/tgt-train.txt", tokenizer)
    val_dataset = Graph2Smiles_USPTO50("data/USPTO50/src-val.txt", "data/USPTO50/tgt-val.txt", tokenizer)
    train_model(opt, train_dataset, val_dataset, tokenizer)

if __name__ == "__main__":
    main()
