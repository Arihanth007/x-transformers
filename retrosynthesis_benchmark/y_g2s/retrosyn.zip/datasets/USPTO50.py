import torch
import torch.nn.functional as F
import torch_geometric

from torch.utils.data import Dataset

from rdkit import Chem

class USPTO50(Dataset):
    def __init__(self, product_smiles_path: str, reactants_smiles_path: str, tokenizer, device='cpu') -> None:
        with open(product_smiles_path, "r") as f:
            product_smiles = f.readlines()

        with open(reactants_smiles_path, "r") as f:
            reactants_smiles = f.readlines()

        assert(len(product_smiles) == len(reactants_smiles))
        dataset = list(zip(product_smiles, reactants_smiles))

        longest_string_len = 0
        self.processed_dataset = []
        for product, reactants in dataset:
            indexed_product = tokenizer.wrap_and_tokenize(product)
            indexed_reactants = tokenizer.wrap_and_tokenize(reactants)
            longest_string_len = max(longest_string_len, len(indexed_product), len(indexed_reactants))
            self.processed_dataset.append((indexed_product.to(device=device), indexed_reactants.to(device=device)))
        print("longest tokenized string:", longest_string_len)

    def __getitem__(self, idx):
        return self.processed_dataset[idx]

    def __len__(self):
        return len(self.processed_dataset)

# adapted from https://pytorch-geometric.readthedocs.io/en/latest/_modules/torch_geometric/utils/smiles.html#from_smiles
def from_smiles(smiles, with_hydrogen=False, kekulize=False):
    mol = Chem.MolFromSmiles(smiles)
    if with_hydrogen:
        mol = Chem.AddHs(mol)
    if kekulize:
        mol = Chem.Kekulize(mol)

    x_map = {
        'chirality': [
            'CHI_UNSPECIFIED',
            'CHI_TETRAHEDRAL_CW',
            'CHI_TETRAHEDRAL_CCW',
            'CHI_OTHER',
        ],
        'hybridization': [
            'UNSPECIFIED',
            'S',
            'SP',
            'SP2',
            'SP3',
            'SP3D',
            'SP3D2',
            'OTHER',
        ],
        'is_aromatic': [False, True],
        'is_in_ring': [False, True],
    }

    e_map = {
        'bond_type': [
            'misc',
            'SINGLE',
            'DOUBLE',
            'TRIPLE',
            'AROMATIC',
        ],
        'stereo': [
            'STEREONONE',
            'STEREOZ',
            'STEREOE',
            'STEREOCIS',
            'STEREOTRANS',
            'STEREOANY',
        ],
        'is_conjugated': [False, True],
    }

    atom2idx = {
        5 : 0,
        8 : 1,
        6 : 2,
        7 : 3,
        9 : 4,
        16 : 5,
        17 : 6,
        14 : 7,
        15 : 8,
        34 : 9,
        35 : 10,
        50 : 11, 
        53 : 12  
    }

    num_atoms = mol.GetNumAtoms()
    x = torch.zeros((num_atoms, len(atom2idx) + 11 + 12 + 9 + 5 + 8 + 1 + 1), dtype=torch.float32)
    for i, atom in enumerate(mol.GetAtoms()):
        features = [
            F.one_hot(torch.LongTensor([atom2idx[atom.GetAtomicNum()]]), len(atom2idx)),
            F.one_hot(torch.LongTensor([atom.GetTotalDegree()]), 11),
            F.one_hot(torch.LongTensor([atom.GetFormalCharge() + 5]), 12),
            F.one_hot(torch.LongTensor([atom.GetTotalNumHs()]), 9),
            F.one_hot(torch.LongTensor([atom.GetNumRadicalElectrons()]), 5),
            F.one_hot(torch.LongTensor([x_map['hybridization'].index(str(atom.GetHybridization()))]), len(x_map["hybridization"])),
            torch.LongTensor([[atom.GetIsAromatic()]]),
            torch.LongTensor([[atom.IsInRing()]]),
        ]
        x[i] = torch.cat(features, dim=1).reshape(-1)

    edge_attrs = []
    edge_indices = []
    for bond in mol.GetBonds():
        i = bond.GetBeginAtomIdx()
        j = bond.GetEndAtomIdx()
        edge_indices += [[i, j], [j, i]]
        features = [
            F.one_hot(torch.LongTensor([e_map['bond_type'].index(str(bond.GetBondType()))]), len(e_map['bond_type'])),
            torch.LongTensor([[bond.GetIsConjugated()]]),
        ]
        features = torch.cat(features, dim=1).reshape(-1)
        edge_attrs += [features, features]

    edge_index = torch.tensor(edge_indices)
    edge_index = edge_index.t().to(torch.long).view(2, -1)
    edge_attr = torch.stack(edge_attrs, dim=0).to(dtype=torch.float32)

    if edge_index.numel() > 0:  # Sort indices.
        perm = (edge_index[0] * x.size(0) + edge_index[1]).argsort()
        edge_index, edge_attr = edge_index[:, perm], edge_attr[perm]

    return torch_geometric.data.Data(x=x, edge_index=edge_index, edge_attr=edge_attr, smiles=smiles)

class Graph2Smiles_USPTO50(Dataset):
    def __init__(self, product_smiles_path: str, reactants_smiles_path: str, tokenizer, device='cpu') -> None:
        with open(product_smiles_path, "r") as f:
            product_smiles = f.readlines()

        with open(reactants_smiles_path, "r") as f:
            reactants_smiles = f.readlines()

        assert(len(product_smiles) == len(reactants_smiles))
        dataset = list(zip(product_smiles, reactants_smiles))

        longest_string_len = 0
        self.processed_dataset = []
        for product, reactants in dataset:
            indexed_product = tokenizer.wrap_and_tokenize(product)
            indexed_reactants = tokenizer.wrap_and_tokenize(reactants)
            longest_string_len = max(longest_string_len, len(indexed_product), len(indexed_reactants))

            product_smiles = product.replace(' ', '')
            data = from_smiles(product_smiles)
            self.processed_dataset.append((data, indexed_product.to(device=device), indexed_reactants.to(device=device)))

        print("longest tokenized string:", longest_string_len)

    def __getitem__(self, idx):
        return self.processed_dataset[idx]

    def __len__(self):
        return len(self.processed_dataset)