import torch
import numpy as np

class SMILESTokenizer:
    START_TOKEN = '$'
    END_TOKEN = '^'
    PAD_TOKEN = '~'

    def __init__(self, smiles_path: list) -> None:
        from collections import Counter
        all_tokens = Counter()

        for path in smiles_path:
            with open(path, "r") as f:
                smiles = f.readlines()

            for s in smiles:
                all_tokens.update(s.split())

        assert(self.START_TOKEN not in all_tokens)
        assert(self.END_TOKEN not in all_tokens)
        assert(self.PAD_TOKEN not in all_tokens)
        all_tokens.update([self.START_TOKEN, self.END_TOKEN, self.PAD_TOKEN])
      
        self.all_tokens = all_tokens
        total_tokens = sum(all_tokens.values())
        print("number of tokens:", total_tokens)
        print("number of unique tokens:", len(all_tokens))

        self.token2idx = { tok : idx for idx, tok in enumerate(all_tokens) }
        self.idx2token = { v : k for k, v in self.token2idx.items() }

        self.token_weights = np.asarray([total_tokens/all_tokens[self.idx2token[idx]]/86 for idx in range(len(all_tokens))])
        # print(self.token_weights)
        # print(np.sqrt(self.token_weights))
        self.token_weights = np.clip(np.sqrt(self.token_weights), 0, 25)
        # self.token_weights = np.asarray([1/np.power(all_tokens[self.idx2token[idx]], 0.2) for idx in range(len(all_tokens))])
        # self.token_weights /= np.sum(self.token_weights) / 100

    def get_token_index(self, tok):
        return self.token2idx[tok]

    def wrap_and_tokenize(self, string):
        return self.tokenize(self.wrap(string))

    def tokenize(self, string):
        return torch.LongTensor([self.token2idx[t] for t in string.split()])

    def get_token_weights(self):
        return torch.Tensor(self.token_weights)

    def wrap(self, string):
        return self.START_TOKEN + ' ' +  string + ' '  + self.END_TOKEN

    def reverse_tokenize(self, tokens):
        return "".join([self.idx2token[tok] for tok in tokens])

    @property
    def vocab_size(self):
        return len(self.all_tokens)