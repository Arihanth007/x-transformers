import os
import logging
import datetime
import time

import torch
import torch.nn as nn
from torch.nn.utils.rnn import pad_sequence

import nltk
import numpy as np
from rdkit import Chem, DataStructs
from rdkit.Chem import Draw, AllChem

from tqdm import tqdm

import wandb

from rdkit import RDLogger  
RDLogger.DisableLog('rdApp.*')

from model.base import RetrosynthesisBaseNetwork

class Graph2SmilesBaseNetwork(RetrosynthesisBaseNetwork):
    def __init__(self, opt, logger):
        super().__init__(opt, logger)

    def set_criterion(self):
        config = self.opt["config"]
        self.criterion = nn.CrossEntropyLoss(
            ignore_index=self.tokenizer.get_token_index(self.tokenizer.PAD_TOKEN),
            weight=self.tokenizer.get_token_weights() if config["class_reweighting"] else None,
            reduction='none',
            label_smoothing=config["label_smoothing"]
        )

    def set_data_loader(self, train_dataset, validation_dataset, tokenizer):
        config = self.opt["config"]

        def collate_fn_pad(list_pairs_seq_target):
            data, seqs, targets = zip(*list_pairs_seq_target)

            from torch_geometric.data import Batch
            data_batched = Batch.from_data_list(data)
            seqs_padded_batched = pad_sequence(seqs, padding_value=tokenizer.get_token_index(self.tokenizer.PAD_TOKEN))
            targets_padded_batched = pad_sequence(targets, padding_value=tokenizer.get_token_index(self.tokenizer.PAD_TOKEN))
            assert seqs_padded_batched.shape[1] == targets_padded_batched.shape[1]
            return data_batched, seqs_padded_batched, targets_padded_batched
    
        from torch.utils.data import DataLoader        
        self.train_dataset = train_dataset
        self.validation_dataset = validation_dataset
        self.train_loader = DataLoader(dataset=train_dataset, batch_size=config["batch_size"], collate_fn=collate_fn_pad, shuffle=True)
        
        # bucket ordering for evaluation
        train_bucket_order = np.lexsort(np.asarray([(len(tgt), len(prod)) for _, prod, tgt in train_dataset]).T)
        validation_bucket_order = np.lexsort(np.asarray([(len(tgt), len(prod)) for _, prod, tgt in validation_dataset]).T)
        self.train_bucket_loader = DataLoader(dataset=train_dataset, batch_size=config["batch_size"], sampler=train_bucket_order, collate_fn=collate_fn_pad)
        self.validation_bucket_loader = DataLoader(dataset=validation_dataset, batch_size=config["batch_size"], sampler=validation_bucket_order, collate_fn=collate_fn_pad)
        
        self.validation_loader = DataLoader(dataset=validation_dataset, batch_size=config["batch_size"], shuffle=False)
        self.tokenizer = tokenizer

        self.logger.info("Number of training samples: %d" % (len(train_dataset)))
        self.logger.info("Number of validation samples: %d" % (len(validation_dataset)))

    def learn(self, verbose=False):
        config = self.opt["config"]
        best_val_stats, best_selection_value = None, np.Inf
        for epoch_no in range(1, config["epochs"] + 1):
            accumlated_train_loss, num_tokens_processed = 0.0, 0

            start_time = time.time()
            self.train() # set to training mode (validation might have set to eval mode)
            self.optimizer.zero_grad(set_to_none=True)
            for step, (data, _, target_reactants) in enumerate(tqdm(self.train_loader, desc="Epoch progress", unit=" batches", leave=False)):
                # target_reactants: [padded_target_seqlen, batch_size]
                data, target_reactants = data.to(self.device, non_blocking=True), target_reactants.to(self.device, non_blocking=True)

                predicted_reactants = self(data, target_reactants)
                target_reactants = target_reactants[1:]
                # predicted_reactants:  [padded_target_seqlen - 1, batch_size, vocab_size]
                # target_reactants:     [padded_target_seqlen - 1, batch_size]

                vocab_size = predicted_reactants.shape[-1]

                predicted_reactants = predicted_reactants.view(-1, vocab_size)
                target_reactants = target_reactants.view(-1)

                target_padding_mask = target_reactants != self.tokenizer.get_token_index(self.tokenizer.PAD_TOKEN)

                loss = self.criterion(predicted_reactants, target_reactants)
                loss = loss * target_padding_mask
                loss = loss.sum()
                
                num_tokens = target_padding_mask.sum()
                accumlated_train_loss += loss.detach()
                num_tokens_processed += num_tokens.detach()

                loss = loss / num_tokens
                loss.backward()
                if (step + 1) % config.get("gradient_accumulation_steps", 1) == 0:
                    torch.nn.utils.clip_grad_norm_(self.parameters(), 0.1)
                    self.optimizer.step()
                    self.optimizer.zero_grad(set_to_none=True)

                if self.scheduler and config["scheduler"].get("step_location", False) == "iteration":
                    if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                        self.scheduler.step(loss.item())
                    else:
                        self.scheduler.step()

                if config["wandb"].get("log_iterationwise", False):
                    LRs = [param_group['lr'] for param_group in self.optimizer.param_groups]
                    assert(len(LRs) == 1)
                    wandb.log({
                        "iter_learning_rate" : float(LRs[0]),
                        "iter_train_loss" : loss.item(),
                    })

            avg_epoch_train_loss = accumlated_train_loss.item() / num_tokens_processed.item()

            detailed_stats = epoch_no % config["epochs_to_dump_detailed_validation_stats"] == 0

            # compute training_stats
            if epoch_no % config["epochs_to_dump_detailed_training_stats"] == 0:
                training_stats, _ = self.evaluate(self.train_bucket_loader, True)

            # compute validation stats
            validation_stats, val_predictions_table = self.evaluate(self.validation_bucket_loader, detailed_stats)
            avg_epoch_validation_loss = validation_stats["avg_loss"]
            selection_value = validation_stats["avg_loss"]

            if self.scheduler and config["scheduler"].get("step_location", "epoch") == "epoch":
                if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    self.scheduler.step(selection_value)
                else:
                    self.scheduler.step()

            LRs = [param_group['lr'] for param_group in self.optimizer.param_groups]
            learning_rate = LRs[0]
            assert(len(LRs) == 1)
            self.logs['learning_rate'].write(str(learning_rate) + '\n')
            self.logs['train_loss'].write(str(avg_epoch_train_loss) + '\n')
            self.logs['val_loss'].write(str(avg_epoch_validation_loss) + '\n')

            is_best_model = best_selection_value - selection_value > config["best_model_threshold"]
            if is_best_model:
                best_selection_value = selection_value
                best_val_stats = validation_stats
                wandb.run.summary["best_val_stats"] = validation_stats
                self.save_model(self.generate_path("best_val_model.pth"))

            end_time = time.time()

            if verbose:
                self.logger.info("[%d] Epoch completed (%s)", epoch_no, str(datetime.timedelta(seconds=end_time - start_time)))
                self.logger.info("\tlearning rate: %e", learning_rate)
                self.logger.info("\taverage loop loss: %.4f", avg_epoch_train_loss)
                if epoch_no % config["epochs_to_dump_detailed_training_stats"] == 0:
                    self.logger.info("\tTraining Stats:")
                    self.print_stats(training_stats)
                self.logger.info("\tValidation Stats:")
                if is_best_model:
                    self.logger.info("\t\tCURRENT BEST MODEL")
                self.print_stats(validation_stats)
            self.save_checkpoint(self.generate_path("checkpoint.ckpt"))

            wandb_val_predictions_table = None
            if detailed_stats:
                assert(len(val_predictions_table) > 0)
                
                # ripped off from https://colab.research.google.com/github/wandb/examples/blob/master/colabs/rdkit/wb_rdkit.ipynb#scrollTo=m43PgXpID0Pw
                def smiles2image(smiles: str, width: int = 200, height: int = 200) -> "PIL.Image":
                    molecule = Chem.MolFromSmiles(smiles)
                    if not molecule:
                        return None
                    AllChem.Compute2DCoords(molecule)
                    AllChem.GenerateDepictionMatching2DStructure(molecule, molecule)
                    pil_image = Chem.Draw.MolToImage(molecule, size=(width, height))
                    return wandb.Image(pil_image)

                wandb_val_predictions_table = wandb.Table(columns=[
                    "product_smiles", "target_smiles", "predicted_smiles",
                    "product_smiles_2d", "target_smiles_2d", "predicted_smiles_2d",
                    "grammatically_valid", "chemically_reasonable", "correct_prediction",
                    "smiles_edit_distance", "tanimoto_coeff"])

                for pred in val_predictions_table:
                    wandb_val_predictions_table.add_data(
                        pred["product_smiles"], pred["target_smiles"], pred["predicted_smiles"],
                        smiles2image(pred["product_smiles"]), smiles2image(pred["target_smiles"]), smiles2image(pred["predicted_smiles"]),
                        pred["grammatically_valid"], pred["chemically_reasonable"], pred["correct_prediction"],
                        pred["smiles_edit_distance"], pred["tanimoto_coeff"]
                    )

            if config["wandb"].get("log_epochwise", True):
                assert(len(LRs) == 1)
                log_entry = {
                    "epoch" : epoch_no,
                    "learning_rate" : float(LRs[0]),
                    "train_loss" : avg_epoch_train_loss,
                    "val_stats" : validation_stats,
                    "best_val_stats" : best_val_stats
                }
                if wandb_val_predictions_table:
                    log_entry["validation_predictions"] = wandb_val_predictions_table
                if epoch_no % config["epochs_to_dump_detailed_training_stats"] == 0:
                    log_entry["training_stats"] = training_stats
                wandb.log(log_entry)

        self.logger.info("[best model] selection value: %f", best_selection_value)
        self.print_stats(best_val_stats)
        self.save_model(self.generate_path("final_model.pth"))

    def print_stats(self, stats):
        for key, value in stats.items():
            if isinstance(value, float):
                self.logger.info("\t\t%s: %.4f", key, value)

    def evaluate(self, dataloader, detailed_stats=False, useChiral=False):
        self.eval()
        accumlated_validation_loss, num_tokens_processed = 0.0, 0
        grammatically_valid, chemically_reasonable, correct_prediction, tc_sum, num_samples = 0, 0, 0, 0, 0
        grammatically_valid_i, chemically_reasonable_i, correct_prediction_i, tc_sum_i, token_edit_dist_sum_i = 0, 0, 0, 0, 0
        display = 5

        predictions_table = []
        with torch.no_grad():
            for data, product, target_reactants in tqdm(dataloader, desc="Evaluation progress", unit=" batches", leave=False):
                # product:          [padded_source_seqlen, batch_size]
                # target_reactants: [padded_target_seqlen, batch_size]
                data, target_reactants = data.to(self.device, non_blocking=True), target_reactants.to(self.device, non_blocking=True)
            
                padded_target_seqlen, batch_size = target_reactants.shape
    
                predicted_reactants = self(data, target_reactants)
                if detailed_stats:
                    predicted_reactants_inference = self.inference(data, padded_target_seqlen)
                # predicted_reactants:            [padded_target_seqlen - 1, batch_size, vocab_size]
                # predicted_reactants_inference:  [padded_target_seqlen - 1, batch_size]
                
                target_reactants = target_reactants[1:]
                # target_reactants:     [padded_target_seqlen - 1, batch_size]

                vocab_size = predicted_reactants.shape[-1]

                predicted_reactants = predicted_reactants.view(-1, vocab_size)
                target_reactants = target_reactants.view(-1)

                target_padding_mask = target_reactants != self.tokenizer.get_token_index(self.tokenizer.PAD_TOKEN)

                loss = self.criterion(predicted_reactants, target_reactants)
                loss = loss * target_padding_mask
                loss = loss.sum()
                
                num_tokens = target_padding_mask.sum()
                accumlated_validation_loss += loss.detach()
                num_tokens_processed += num_tokens.detach()

                predicted_token_indexes = torch.argmax(predicted_reactants, dim=-1)
               
                padded_target_seqlen_m1 = padded_target_seqlen - 1
                assert(len(target_reactants) % padded_target_seqlen_m1 == 0)
                assert(len(predicted_token_indexes) % padded_target_seqlen_m1 == 0)

                product = product[1:].permute((1, 0))
                target_reactants = target_reactants.view(padded_target_seqlen_m1, batch_size).permute((1, 0))
                predicted_token_indexes = predicted_token_indexes.view(padded_target_seqlen_m1, batch_size).permute((1, 0))
                if detailed_stats:
                    predicted_reactants_inference = predicted_reactants_inference.permute((1, 0))
                # product:                  [batch_size, padded_source_seqlen - 1]
                # target_reactants:         [batch_size, padded_target_seqlen - 1]
                # predicted_token_indexes:  [batch_size, padded_target_seqlen - 1]
                # predicted_token_indexes:  [batch_size, padded_target_seqlen - 1]

                for i in range(batch_size):
                    smi_product = self.tokenizer.reverse_tokenize(product[i].cpu().tolist())
                    smi_target = self.tokenizer.reverse_tokenize(target_reactants[i].cpu().tolist())
                    smi_predicted = self.tokenizer.reverse_tokenize(predicted_token_indexes[i].cpu().tolist())
                    
                    smi_product, smi_target, smi_predicted = "".join(smi_product), "".join(smi_target), "".join(smi_predicted)

                    smi_product = smi_product.split(self.tokenizer.END_TOKEN)[0].split(self.tokenizer.PAD_TOKEN)[0]
                    smi_target = smi_target.split(self.tokenizer.END_TOKEN)[0].split(self.tokenizer.PAD_TOKEN)[0]
                    smi_predicted = smi_predicted.split(self.tokenizer.END_TOKEN)[0].split(self.tokenizer.PAD_TOKEN)[0]

                    canonicalized_smi_target = Chem.CanonSmiles(smi_target, useChiral=useChiral)
                    target_mol = Chem.MolFromSmiles(canonicalized_smi_target)
                    target_mol_fps = Chem.RDKFingerprint(target_mol)

                    predicted_mol = Chem.MolFromSmiles(smi_predicted, sanitize=False)
                    if predicted_mol is not None:
                        grammatically_valid += 1

                    predicted_mol = Chem.MolFromSmiles(smi_predicted)
                    if predicted_mol is not None:
                        chemically_reasonable += 1
                        canonicalized_smi_predicted = Chem.CanonSmiles(smi_predicted, useChiral=useChiral)
                        if canonicalized_smi_predicted == canonicalized_smi_target:
                            correct_prediction += 1
                        predicted_mol_fps = Chem.RDKFingerprint(predicted_mol)
                        tc_sum += DataStructs.FingerprintSimilarity(predicted_mol_fps, target_mol_fps)

                    if detailed_stats:
                        record = {
                            "product_smiles" : smi_product,
                            "target_smiles" : smi_target,
                            "predicted_smiles" : None,
                            "grammatically_valid" : False,
                            "chemically_reasonable" : False,
                            "correct_prediction" : False,
                            "smiles_edit_distance" : None,
                            "tanimoto_coeff" : None
                        }

                        smi_predicted_inference = self.tokenizer.reverse_tokenize(predicted_reactants_inference[i].cpu().tolist())
                        smi_predicted_inference = "".join(smi_predicted_inference)
                        smi_predicted_inference = smi_predicted_inference.split(self.tokenizer.END_TOKEN)[0]
                        edit_dist = nltk.edit_distance(smi_target, smi_predicted_inference)
                        token_edit_dist_sum_i += edit_dist

                        record["predicted_smiles"] = smi_predicted_inference
                        record["smiles_edit_distance"] = edit_dist

                        infer_mol = Chem.MolFromSmiles(smi_predicted_inference, sanitize=False)
                        if infer_mol is not None:
                            record["grammatically_valid"] = True
                            grammatically_valid_i += 1

                        infer_mol = Chem.MolFromSmiles(smi_predicted_inference)
                        if infer_mol is not None:
                            record["chemically_reasonable"] = True
                            chemically_reasonable_i += 1
                            canonicalized_smi_infer = Chem.CanonSmiles(smi_predicted_inference, useChiral=useChiral)
                            if canonicalized_smi_infer == canonicalized_smi_target:
                                record["correct_prediction"] = True
                                correct_prediction_i += 1
                            infer_mol_fps = Chem.RDKFingerprint(infer_mol)
                            tc = DataStructs.FingerprintSimilarity(infer_mol_fps, target_mol_fps)
                            record["tanimoto_coeff"] = tc
                            tc_sum_i += tc
                            
                        predictions_table.append(record)

                    if display > 0:
                        print("Evaluation Sample:")
                        print("product:       ", smi_product)
                        print("target:        ", smi_target)
                        print("predicted - tf:", smi_predicted)
                        if detailed_stats:
                            print("predicted - gd:", smi_predicted_inference)
                        print()
                        display -= 1

                num_samples += batch_size
        
        stats = {
            "avg_loss" : accumlated_validation_loss.item() / num_tokens_processed.item(),
            "grammatically_valid" : grammatically_valid / num_samples,
            "chemically_reasonable" : chemically_reasonable / num_samples,
            "correct_prediction" : correct_prediction / num_samples,
            "tc_for_reasonable_predictions" : tc_sum / chemically_reasonable,
        }
        if detailed_stats:
            stats.update({
                "grammatically_valid_i" : grammatically_valid_i / num_samples,
                "chemically_reasonable_i" : chemically_reasonable_i / num_samples,
                "correct_prediction_i" : correct_prediction_i / num_samples,
                "tc_for_reasonable_predictions_i" : tc_sum_i / chemically_reasonable_i,
                "token_edit_dist_sum_i" : token_edit_dist_sum_i / num_samples
            })
        return stats, predictions_table
    