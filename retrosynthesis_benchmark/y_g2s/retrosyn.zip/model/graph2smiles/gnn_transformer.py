import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_geometric.nn as gnn

import numpy as np
import random

import math

from model.graph2smiles.base import Graph2SmilesBaseNetwork

class PositionalEncoding(nn.Module):
    def __init__(self,
                 emb_size: int,
                 dropout: float,
                 maxlen: int = 200):
        super(PositionalEncoding, self).__init__()
        den = torch.exp(- torch.arange(0, emb_size, 2)* math.log(10000) / emb_size)
        pos = torch.arange(0, maxlen).reshape(maxlen, 1)
        pos_embedding = torch.zeros((maxlen, emb_size))
        pos_embedding[:, 0::2] = torch.sin(pos * den)
        pos_embedding[:, 1::2] = torch.cos(pos * den)
        pos_embedding = pos_embedding.unsqueeze(-2).requires_grad_(False)

        self.dropout = nn.Dropout(dropout)
        self.register_buffer('pos_embedding', pos_embedding)

    def forward(self, token_embedding: torch.Tensor):
        return self.dropout(token_embedding + self.pos_embedding[:token_embedding.size(0), :])

class TokenEmbedding(nn.Module):
    def __init__(self, vocab_size: int, emb_size):
        super(TokenEmbedding, self).__init__()
        self.embedding = nn.Embedding(vocab_size, emb_size)
        self.emb_size = emb_size

    def forward(self, tokens: torch.Tensor):
        return self.embedding(tokens.long()) * math.sqrt(self.emb_size)

class CGCNNConv(gnn.MessagePassing):
    def __init__(self, in_channels, out_channels, edge_dim):
        super().__init__(aggr='sum')
        self.in_channels = in_channels
        self.out_channels = out_channels
        num_merged_features = in_channels * 2 + edge_dim

        self.fc_fs = nn.Linear(num_merged_features, 2 * out_channels)
        self.bn_fs = nn.BatchNorm1d(2 * out_channels)

        self.sigmoid_f = nn.Sigmoid()
        
        self.bn_aggr = nn.BatchNorm1d(out_channels)
        self.softplus_final = nn.Softplus()

    def forward(self, x, edge_index, edge_attr):
        # x: [N, in_channels]
        # edge_index: [2, num_edges]
        # edge_attr: [num_edges, edge_dim]

        # aggr_x: [num_nodes, out_channels]
        aggr_x = self.propagate(edge_index, x=x, edge_attr=edge_attr)
        aggr_x = self.bn_aggr(aggr_x)
        x = self.softplus_final(aggr_x + x)
        return x

    def message(self, x_i, x_j, edge_attr):
        # x_i: [num_edges, in_channels]
        # x_j: [num_edges, in_channels]
        # edge_attr: [num_edges, edge_dim]
        edge_attr = edge_attr.reshape(x_i.shape[0], -1)
        
        # z: [num_edges, in_channels * 2 + edge_dim]
        z = torch.cat((x_i, x_j, edge_attr), dim=1)

        # z: [num_edges, 2 * out_channels]
        z = self.fc_fs(z) 
        z = self.bn_fs(z)
        
        # w: [num_edges, out_channels]
        # v: [num_edges, out_channels]
        w, v = z.chunk(2, dim=1)

        w = torch.sigmoid(w)
        v = F.softplus(v)
        return w  * v

class GraphEncoder(nn.Module):
    def __init__(self, embedding_size):
        super().__init__()
        
        self.fc = nn.Linear(60, 128)

        self.conv1 = CGCNNConv(in_channels=128, out_channels=128, edge_dim=6)
        self.conv2 = CGCNNConv(in_channels=128, out_channels=128, edge_dim=6)
        self.conv3 = CGCNNConv(in_channels=128, out_channels=embedding_size, edge_dim=6)

    def forward(self, data):
        x, edge_index, edge_attr = data.x, data.edge_index, data.edge_attr

        x = self.fc(x)
        x = F.relu(self.conv1(x, edge_index, edge_attr))
        x = F.relu(self.conv2(x, edge_index, edge_attr))
        x = self.conv3(x, edge_index, edge_attr)
        return x

class GNNTransformer(Graph2SmilesBaseNetwork):
    def __init__(self, opt, logger, vocab_size):
        super().__init__(opt, logger)

        config = opt["config"]["architecture"]
        self.config = config

        EMBEDDING_SIZE = config["embedding_size"]
        DROPOUT = config["dropout"]
        
        self.encoder = GraphEncoder(EMBEDDING_SIZE)

        decoder_layer = nn.TransformerDecoderLayer(
                                d_model=EMBEDDING_SIZE,
                                nhead=config["nhead"],
                                dim_feedforward=config["dim_feedforward"],
                                dropout=DROPOUT)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=config["num_decoder_layers"])

        self.generator = nn.Linear(EMBEDDING_SIZE, vocab_size)
        self.tgt_tok_emb = TokenEmbedding(vocab_size, EMBEDDING_SIZE)
        self.positional_encoding = PositionalEncoding(EMBEDDING_SIZE, dropout=DROPOUT)
        
        self.reset_parameters(self.decoder.parameters())
    
    def reset_parameters(self, m):
        # This was aparently important for the original transformer
        if self.config.get("initialization", "xavier_uniform") == "xavier_uniform":
            for p in m:
                if p.dim() > 1:
                    nn.init.xavier_uniform_(p)

    def generate_square_subsequent_mask(self, sz):
        mask = (torch.triu(torch.ones((sz, sz), device=self.device)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask

    def create_mask(self, tgt):
        tgt_seq_len = tgt.shape[0]
        tgt_mask = self.generate_square_subsequent_mask(tgt_seq_len)
        tgt_padding_mask = (tgt == self.tokenizer.get_token_index(self.tokenizer.PAD_TOKEN)).transpose(0, 1)
        return tgt_mask, tgt_padding_mask

    def forward(self, data, tgt):
        # tgt: [padded_seqlen, batch_size]
        tgt_input = tgt[:-1, :]
        tgt_mask, tgt_padding_mask = self.create_mask(tgt_input)
        batch_size = tgt.shape[1]

        # tgt_embeddings: [padded_seqlen, batch_size, embedding_size]
        tgt_embeddings = self.positional_encoding(self.tgt_tok_emb(tgt_input))

        # memory: [total_num_nodes_batch, embedding_size]
        memory_merged = self.encode(data)

        data_list = data.to_data_list()
        num_nodes_lst = [d.x.shape[0] for d in data_list]
        num_nodes_padded = max(num_nodes_lst)

        memory = torch.zeros((num_nodes_padded, batch_size, 128), dtype=memory_merged.dtype, device=memory_merged.device)
        memory_key_padding_mask = torch.zeros((batch_size, num_nodes_padded), device=memory.device)

        running_sum = 0
        for b_idx, num_nodes in enumerate(num_nodes_lst):
            memory_key_padding_mask[b_idx, num_nodes:] = 1
            memory[:num_nodes, b_idx, :] = memory_merged[running_sum : running_sum + num_nodes]
            running_sum += num_nodes
        
        # memory: [largest_node_size, batch_size, embedding_size]

        # print(tgt.shape)
        # print(tgt_embeddings.shape)
        # print(memory.shape)
        # print(tgt_mask.shape)
        # print(tgt_padding_mask.shape)
        logits = self.decoder(tgt_embeddings, memory, tgt_mask=tgt_mask, memory_mask=None, tgt_key_padding_mask=tgt_padding_mask, memory_key_padding_mask=memory_key_padding_mask)
        logits = self.generator(logits)
        return logits

    def encode(self, data):
        return self.encoder(data)

    def inference(self, data, max_len):
        # src: [padded_source_seqlen, batch_size]
        batch_size = data.num_graphs

        # memory: [total_num_nodes_batch, embedding_size]
        memory_merged = self.encode(data)

        data_list = data.to_data_list()
        num_nodes_lst = [d.x.shape[0] for d in data_list]
        num_nodes_padded = max(num_nodes_lst)

        memory = torch.zeros((num_nodes_padded, batch_size, 128), dtype=memory_merged.dtype, device=memory_merged.device)
        memory_key_padding_mask = torch.zeros((batch_size, num_nodes_padded), device=memory.device)

        running_sum = 0
        for b_idx, num_nodes in enumerate(num_nodes_lst):
            memory_key_padding_mask[b_idx, num_nodes:] = 1
            memory[:num_nodes, b_idx, :] = memory_merged[running_sum : running_sum + num_nodes]
            running_sum += num_nodes
        
        decoded_tokens = torch.ones((1, batch_size), device=self.device, dtype=torch.long).fill_(self.tokenizer.get_token_index(self.tokenizer.START_TOKEN))
        # decoded_tokens: [1, batch_size]

        for i in range(max_len):
            tgt_mask = self.generate_square_subsequent_mask(i + 1)
            decoded_embeddings = self.positional_encoding(self.tgt_tok_emb(decoded_tokens))
            # decoded_embeddings: [cur_decoded_seqlen, batch_size, 128]

            logits = self.decoder(decoded_embeddings, memory, tgt_mask=tgt_mask, memory_key_padding_mask=memory_key_padding_mask)
            logits = self.generator(logits)
            # logits: [cur_decoded_seqlen, batch_size, vocab_size]

            logits = logits[-1:]
            # logits: [1, batch_size]

            last_token = torch.argmax(logits, dim=-1)
            # last_token: [1, batch_size]

            decoded_tokens = torch.cat([decoded_tokens, last_token], dim=0)
        return decoded_tokens[1:]
