import os
import logging
import datetime
import time

import torch
import torch.nn as nn

import numpy as np
from rdkit import Chem, DataStructs

from tqdm import tqdm

import wandb
import adabound

from rdkit import RDLogger  
RDLogger.DisableLog('rdApp.*')

class RetrosynthesisBaseNetwork(nn.Module):
    def __init__(self, opt, logger):
        super().__init__()
        self.opt = opt
        self.device = torch.device(self.opt["device"])
        self.logger = logger

    def init_train(self):
        self.train()
        
        model_category = self.opt["model_category"]
        model_subdir = self.opt.get("model_subdir", "")

        from datetime import datetime
        timestamp = datetime.now().strftime("%Y-%m-%d %H_%M_%S")
        self.output_dir = os.path.join("output", model_category, model_subdir, timestamp)
        os.makedirs(self.output_dir)
        
        file_handler = logging.FileHandler(filename=os.path.join(self.output_dir, "log.txt"))
        self.logger.addHandler(file_handler)

        import json
        opt_prettyprint_str = json.dumps(self.opt, indent=4)
        self.logger.info("Model: %s", model_category)
        self.logger.info("Output directory: %s", self.output_dir)
        self.logger.info(("Options:\n" + opt_prettyprint_str).replace("\n", "\n           "))

        self.logs = {
            "train_loss" : open(os.path.join(self.output_dir, "train_loss.txt"), "w", buffering=1),
            "val_loss" : open(os.path.join(self.output_dir, "val_loss.txt"), "w", buffering=1),
            "learning_rate" : open(os.path.join(self.output_dir, "learning_rate.txt"), "w", buffering=1)
        }

    def set_optimizer_and_scheduler(self):
        config = self.opt["config"]
        str2optimizer = {
            "AdamW" : torch.optim.AdamW,
            "SGD" : torch.optim.SGD,
            "AdaBound" : adabound.AdaBound
        }

        self.optimizer = str2optimizer[config["optimizer"]["type"]](self.parameters(), **config["optimizer"]["params"])
        self.logger.info("[%s] %s", config["optimizer"]["type"], config["optimizer"]["params"])

        self.scheduler = None
        if "scheduler" in config:
            scheduler_types = {
                "ReduceLROnPlateau" : torch.optim.lr_scheduler.ReduceLROnPlateau,
                "CyclicLR" : torch.optim.lr_scheduler.CyclicLR,
                "ExponentialLR" : torch.optim.lr_scheduler.ExponentialLR,
                "OneCycleLR" : torch.optim.lr_scheduler.OneCycleLR
            }
            self.scheduler = scheduler_types[config["scheduler"]["type"]](self.optimizer, **config["scheduler"]["params"])
            self.logger.info("[%s] %s", config["scheduler"]["type"], config["scheduler"]["params"])

        total_params = sum(p.numel() for p in self.parameters())
        train_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        self.logger.info("Total Parameters: %d", total_params)
        self.logger.info("Trainable Parameters: %d", train_params)
        self.logger.info(self)
        
    def generate_path(self, *rpath):
        return os.path.join(self.output_dir, *rpath)

    def save_checkpoint(self, path):
        torch.save({
            'state_dict': self.state_dict(),
            'optimizer' : self.optimizer.state_dict(),
        }, path)

    def load_checkpoint(self, path):
        checkpoint = torch.load(path)
        self.load_state_dict(checkpoint['state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])

    def save_model(self, path):
        torch.save(self.state_dict(), path)

    def load_model(self, path):
        self.load_state_dict(torch.load(path))