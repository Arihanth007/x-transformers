import torch
import torch.nn as nn
import numpy as np
import random

from model.smiles2smiles.base import Smiles2SmilesBaseNetwork

class EncoderRNN(nn.Module):
    def __init__(self, vocab_size, embedding_size, hidden_size, num_layers, bidirectional, dropout):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        self.embedding = nn.Embedding(vocab_size, embedding_size)
    
        self.lstm = nn.LSTM(embedding_size, hidden_size, num_layers, bidirectional = bidirectional, dropout = dropout)
        self.dropout = nn.Dropout(dropout)

    def forward(self, src):
        # src: [padded_source_seqlen, batch_size]

        src_embeddings = self.dropout(self.embedding(src))
        # src_embeddings: [padded_source_seqlen, batch size, embedding_size]

        outputs, (hs, cs) = self.lstm(src_embeddings)
        # outputs: [padded_source_seqlen, batch_size, num_directions * hidden_size]
        # hs: [num_layers * num_directions, batch size, hidden_size]
        # cs: [num_layers * num_directions, batch size, hidden_size]

        return outputs, hs, cs
        
class DecoderRNN(nn.Module):
    def __init__(self, output_size, embedding_size, hidden_size, num_layers, bidirectional, dropout):
        super().__init__()
        
        self.output_size = output_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        self.embedding = nn.Embedding(output_size, embedding_size)

        self.lstm = nn.LSTM(embedding_size, hidden_size, num_layers, bidirectional = bidirectional, dropout = dropout)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, tgt, ctx_hidden, ctx_cell, encoder_outputs):
        # tgt: [padded_target_seqlen, batch_size]
        # ctx_hidden: [num_layers * num_directions, batch_size, hidden_size]
        # ctx_cell: [num_layers * num_directions, batch_size, hidden_size]
        # encoder_outputs: [padded_source_seqlen, batch_size, num_directions * hidden_size]

        tgt_embeddings = self.dropout(self.embedding(tgt))
        # embedded = [padded_target_seqlen, batch_size, embedding_size]

# attn_weights = F.softmax(self.attn(torch.cat((embedded[0], hidden[0]), 1)), dim=1)
#         attn_applied = torch.bmm(attn_weights.unsqueeze(0),
#                                  encoder_outputs.unsqueeze(0))

#         output = torch.cat((embedded[0], attn_applied[0]), 1)
#         output = self.attn_combine(output).unsqueeze(0)

#         output = F.relu(output)
#         output, hidden = self.gru(output, hidden)

#         output = F.log_softmax(self.out(output[0]), dim=1)
#         return output, hidden, attn_weights

        outputs, _ = self.lstm(tgt_embeddings, (ctx_hidden, ctx_cell))
        # outputs: [padded_target_seqlen, batch_size, hidden_size * num_directions]
        
        return outputs

class BottleneckLSTM(Smiles2SmilesBaseNetwork):
    def __init__(self, opt, logger, vocab_size):
        super().__init__(opt, logger)

        EMBEDDING_SIZE = 128
        HIDDEN_SIZE = 128
        NUM_LAYERS = 2

        DROPOUT = 0.2

        ENC_BIDIR = False
        DEC_BIDIR = False

        self.encoder = EncoderRNN(vocab_size, EMBEDDING_SIZE, HIDDEN_SIZE, NUM_LAYERS, ENC_BIDIR, DROPOUT)
        self.decoder = DecoderRNN(vocab_size, EMBEDDING_SIZE, HIDDEN_SIZE, NUM_LAYERS, DEC_BIDIR, DROPOUT)

        self.generator = nn.Linear(HIDDEN_SIZE, vocab_size)

        assert self.encoder.hidden_size == self.decoder.hidden_size, \
            "Hidden dimensions of encoder and decoder must be equal!"
        assert self.encoder.num_layers == self.decoder.num_layers, \
            "Encoder and decoder must have equal number of layers!"
        
    def forward(self, src, tgt):        
        # src: [padded_source_seqlen, batch_size]
        # tgt: [padded_target_seqlen, batch_size]

        ctx_hidden, ctx_cell = self.encoder(src)
        # ctx_hidden: [num_layers * num_directions, batch_size, hidden_size]
        # ctx_cell: [num_layers * num_directions, batch_size, hidden_size]
        
        decoded_outputs = self.decoder(tgt[:-1], ctx_hidden, ctx_cell)
        # decoded_outputs: [padded_target_seqlen, batch_size, hidden_size]
        
        decoded_outputs = self.generator(decoded_outputs)
        # decoded_outputs: [padded_target_seqlen, batch_size, vocab_size]
        
        return decoded_outputs

    def inference(self, src, max_len):
        # src: [padded_source_seqlen, batch_size]
        _, batch_size = src.shape

        ctx_hidden, ctx_cell = self.encoder(src)
        # ctx_hidden: [num_layers * num_directions, batch_size, hidden_size]
        # ctx_cell: [num_layers * num_directions, batch_size, hidden_size]

        decoded_tokens = torch.ones((1, batch_size), device=self.device, dtype=torch.long).fill_(self.tokenizer.get_token_index(self.tokenizer.START_TOKEN))
        # decoded_tokens: [1, batch_size]

        for i in range(max_len):
            logits = self.decoder(decoded_tokens, ctx_hidden, ctx_cell)
            logits = self.generator(logits)
            # logits: [cur_decoded_seqlen, batch_size, vocab_size]

            logits = logits[-1:]
            # logits: [1, batch_size]

            last_token = torch.argmax(logits, dim=-1)
            # last_token: [1, batch_size]

            decoded_tokens = torch.cat([decoded_tokens, last_token], dim=0)
        return decoded_tokens[1:]