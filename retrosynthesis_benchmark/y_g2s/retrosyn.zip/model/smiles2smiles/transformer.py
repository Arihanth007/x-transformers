from lib2to3.pgen2 import token
import torch
import torch.nn as nn
import numpy as np
import random

import math 

from model.smiles2smiles.base import Smiles2SmilesBaseNetwork
from datasets.USPTO50 import USPTO50

class PositionalEncoding(nn.Module):
    def __init__(self,
                 emb_size: int,
                 dropout: float,
                 maxlen: int = 200):
        super(PositionalEncoding, self).__init__()
        den = torch.exp(- torch.arange(0, emb_size, 2)* math.log(10000) / emb_size)
        pos = torch.arange(0, maxlen).reshape(maxlen, 1)
        pos_embedding = torch.zeros((maxlen, emb_size))
        pos_embedding[:, 0::2] = torch.sin(pos * den)
        pos_embedding[:, 1::2] = torch.cos(pos * den)
        pos_embedding = pos_embedding.unsqueeze(-2).requires_grad_(False)

        self.dropout = nn.Dropout(dropout)
        self.register_buffer('pos_embedding', pos_embedding)

    def forward(self, token_embedding: torch.Tensor):
        return self.dropout(token_embedding + self.pos_embedding[:token_embedding.size(0), :])

class TokenEmbedding(nn.Module):
    def __init__(self, vocab_size: int, emb_size):
        super(TokenEmbedding, self).__init__()
        self.embedding = nn.Embedding(vocab_size, emb_size)
        self.emb_size = emb_size

    def forward(self, tokens: torch.Tensor):
        return self.embedding(tokens.long()) * math.sqrt(self.emb_size)

class Transformer(Smiles2SmilesBaseNetwork):
    def __init__(self, opt, logger, vocab_size):
        super().__init__(opt, logger)

        config = opt["config"]["architecture"]
        self.config = config

        EMBEDDING_SIZE = config["embedding_size"]
        DROPOUT = config["dropout"]

        self.transformer = nn.Transformer(d_model=EMBEDDING_SIZE,
                                       nhead=config["nhead"],
                                       num_encoder_layers=config["num_encoder_layers"],
                                       num_decoder_layers=config["num_decoder_layers"],
                                       dim_feedforward=config["dim_feedforward"],
                                       dropout=DROPOUT)
        self.generator = nn.Linear(EMBEDDING_SIZE, vocab_size)
        self.src_tok_emb = TokenEmbedding(vocab_size, EMBEDDING_SIZE)
        self.tgt_tok_emb = self.src_tok_emb if config["share_embeddings"] else TokenEmbedding(vocab_size, EMBEDDING_SIZE)
        self.positional_encoding = PositionalEncoding(EMBEDDING_SIZE, dropout=DROPOUT)

        if config["tie_decoder_embedding"]:
            self.generator.weight = self.src_tok_emb.embedding.weight

        self.reset_parameters()
    
    def reset_parameters(self):
        # This was aparently important for the original transformer
        if self.config.get("initialization", "xavier_uniform") == "xavier_uniform":
            for p in self.parameters():
                if p.dim() > 1:
                    nn.init.xavier_uniform_(p)

    def generate_square_subsequent_mask(self, sz):
        mask = (torch.triu(torch.ones((sz, sz), device=self.device)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask

    def create_mask(self, src, tgt):
        src_seq_len = src.shape[0]
        tgt_seq_len = tgt.shape[0]

        tgt_mask = self.generate_square_subsequent_mask(tgt_seq_len)
        src_mask = torch.zeros((src_seq_len, src_seq_len), device=self.device).type(torch.bool)

        src_padding_mask = (src == self.tokenizer.get_token_index(self.tokenizer.PAD_TOKEN)).transpose(0, 1)
        tgt_padding_mask = (tgt == self.tokenizer.get_token_index(self.tokenizer.PAD_TOKEN)).transpose(0, 1)
        return src_mask, tgt_mask, src_padding_mask, tgt_padding_mask

    def forward(self, src, tgt):
        tgt_input = tgt[:-1, :]
        src_mask, tgt_mask, src_padding_mask, tgt_padding_mask = self.create_mask(src, tgt_input)
        return self.forward_transformer(src, tgt_input, src_mask, tgt_mask,src_padding_mask, tgt_padding_mask, src_padding_mask)

    def forward_transformer(self,
                    src: torch.Tensor,
                    trg: torch.Tensor,
                    src_mask: torch.Tensor,
                    tgt_mask: torch.Tensor,
                    src_padding_mask: torch.Tensor,
                    tgt_padding_mask: torch.Tensor,
                    memory_key_padding_mask: torch.Tensor):
            src_emb = self.positional_encoding(self.src_tok_emb(src))
            tgt_emb = self.positional_encoding(self.tgt_tok_emb(trg))
            outs = self.transformer(src_emb, tgt_emb, src_mask, tgt_mask, None,
                                    src_padding_mask, tgt_padding_mask, memory_key_padding_mask)
            return self.generator(outs)

    def encode(self, src: torch.Tensor, src_mask = None):
        return self.transformer.encoder(self.positional_encoding(
                            self.src_tok_emb(src)), src_mask)

    def decode(self, tgt: torch.Tensor, memory: torch.Tensor, tgt_mask: torch.Tensor):
        return self.transformer.decoder(self.positional_encoding(
                          self.tgt_tok_emb(tgt)), memory,
                          tgt_mask)

    def inference(self, src, max_len):
        # src: [padded_source_seqlen, batch_size]
        _, batch_size = src.shape

        src_padding_mask = (src == self.tokenizer.get_token_index(self.tokenizer.PAD_TOKEN)).transpose(0, 1)
        # src_padding_mask: [batch_size, padded_source_seqlen]

        src_embeddings = self.positional_encoding(self.src_tok_emb(src))
        # src_embeddings: [padded_source_seqlen, batch_size, vocab_size]

        memory = self.transformer.encoder(src_embeddings, src_key_padding_mask=src_padding_mask)
        # memory: [padded_source_seqlen, batch_size, embedding_size]
        
        decoded_tokens = torch.ones((1, batch_size), device=self.device, dtype=torch.long).fill_(self.tokenizer.get_token_index(self.tokenizer.START_TOKEN))
        # decoded_tokens: [1, batch_size]

        for i in range(max_len):
            tgt_mask = self.generate_square_subsequent_mask(i + 1)
            decoded_embeddings = self.positional_encoding(self.tgt_tok_emb(decoded_tokens))
            # decoded_embeddings: [cur_decoded_seqlen, batch_size, 128]

            logits = self.transformer.decoder(decoded_embeddings, memory, tgt_mask=tgt_mask, memory_key_padding_mask=src_padding_mask)
            logits = self.generator(logits)
            # logits: [cur_decoded_seqlen, batch_size, vocab_size]

            logits = logits[-1:]
            # logits: [1, batch_size]

            last_token = torch.argmax(logits, dim=-1)
            # last_token: [1, batch_size]

            decoded_tokens = torch.cat([decoded_tokens, last_token], dim=0)
        return decoded_tokens[1:]
